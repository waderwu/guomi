
#include <cstdio>
#include "sm3-hash-4way.c"

int main() {
	char output[0x200] = { 0 };
	char input[0x200] = { 0 };
	printf("Input the data:");
	scanf("%512s", input);
	sm3_4way(output, input, strlen(input));
	printf("The output is: %s", output);
}