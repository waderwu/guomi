This repo is for demo of memory static acceleration method.
- 测试文件大小：`g++ sm4fast.cpp fileSizeSpeed.cpp -std=c++11  -O3 -o  fielSize `
